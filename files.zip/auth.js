// shared/auth.js
// JWT signing/verification helpers shared across services.
// Add "jsonwebtoken" and "bcryptjs" to shared/package.json dependencies.

const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

const ACCESS_TOKEN_SECRET = process.env.JWT_ACCESS_SECRET;
const REFRESH_TOKEN_SECRET = process.env.JWT_REFRESH_SECRET;
const ACCESS_TOKEN_TTL = process.env.JWT_ACCESS_TTL || '15m';
const REFRESH_TOKEN_TTL = process.env.JWT_REFRESH_TTL || '30d';

if (!ACCESS_TOKEN_SECRET || !REFRESH_TOKEN_SECRET) {
  // Fail loudly at boot rather than silently signing tokens with "undefined".
  console.error('FATAL: JWT_ACCESS_SECRET and JWT_REFRESH_SECRET must be set in the environment.');
  process.exit(1);
}

function hashPassword(plainPassword) {
  return bcrypt.hash(plainPassword, 12);
}

function verifyPassword(plainPassword, hash) {
  return bcrypt.compare(plainPassword, hash);
}

function signAccessToken(user) {
  // Keep the payload minimal — id and role are all downstream services need.
  return jwt.sign(
    { sub: user.user_id, role: user.role },
    ACCESS_TOKEN_SECRET,
    { expiresIn: ACCESS_TOKEN_TTL }
  );
}

function signRefreshToken(user) {
  return jwt.sign(
    { sub: user.user_id, type: 'refresh' },
    REFRESH_TOKEN_SECRET,
    { expiresIn: REFRESH_TOKEN_TTL }
  );
}

function verifyAccessToken(token) {
  // Throws if invalid/expired — callers should catch and respond 401.
  return jwt.verify(token, ACCESS_TOKEN_SECRET);
}

function verifyRefreshToken(token) {
  return jwt.verify(token, REFRESH_TOKEN_SECRET);
}

module.exports = {
  hashPassword,
  verifyPassword,
  signAccessToken,
  signRefreshToken,
  verifyAccessToken,
  verifyRefreshToken,
};
