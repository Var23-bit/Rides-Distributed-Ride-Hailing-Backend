const express = require('express');
const cors = require('cors');
const crypto = require('crypto');
const { z } = require('zod');
const { query } = require('shared');
const {
  hashPassword,
  verifyPassword,
  signAccessToken,
  signRefreshToken,
  verifyRefreshToken,
} = require('shared/auth');

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 3004;

// --- Validation schemas ---
const registerSchema = z.object({
  role: z.enum(['rider', 'driver']),
  name: z.string().min(1).max(255),
  phone: z.string().min(8).max(20),
  email: z.string().email().optional(),
  password: z.string().min(8).max(128),
  // required only for role === 'driver'
  licenseNumber: z.string().min(1).max(100).optional(),
  vehicleInfo: z.record(z.any()).optional(),
});

const loginSchema = z.object({
  phone: z.string().min(8).max(20),
  password: z.string().min(1),
});

function hashToken(token) {
  // Store only a hash of the refresh token, never the raw value.
  return crypto.createHash('sha256').update(token).digest('hex');
}

// --- POST /auth/register ---
app.post('/auth/register', async (req, res) => {
  const parsed = registerSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: 'Invalid input', details: parsed.error.flatten() });
  }
  const { role, name, phone, email, password, licenseNumber, vehicleInfo } = parsed.data;

  if (role === 'driver' && !licenseNumber) {
    return res.status(400).json({ error: 'licenseNumber is required for driver registration' });
  }

  try {
    const existing = await query('SELECT user_id FROM users WHERE phone = $1', [phone]);
    if (existing.rows.length > 0) {
      return res.status(409).json({ error: 'An account with this phone number already exists' });
    }

    const passwordHash = await hashPassword(password);

    const userResult = await query(
      `INSERT INTO users (role, name, phone, email, password_hash)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING user_id, role, name, phone, email, created_at`,
      [role, name, phone, email || null, passwordHash]
    );
    const user = userResult.rows[0];

    if (role === 'driver') {
      await query(
        `INSERT INTO driver_profiles (user_id, license_number, vehicle_info, is_verified, is_available)
         VALUES ($1, $2, $3, false, false)`,
        [user.user_id, licenseNumber, vehicleInfo ? JSON.stringify(vehicleInfo) : null]
      );
    }

    const accessToken = signAccessToken(user);
    const refreshToken = signRefreshToken(user);
    const decoded = verifyRefreshToken(refreshToken);

    await query(
      `INSERT INTO refresh_tokens (user_id, token_hash, expires_at)
       VALUES ($1, $2, to_timestamp($3))`,
      [user.user_id, hashToken(refreshToken), decoded.exp]
    );

    res.status(201).json({
      user: { id: user.user_id, role: user.role, name: user.name, phone: user.phone },
      accessToken,
      refreshToken,
    });
  } catch (err) {
    console.error('Registration error:', err);
    res.status(500).json({ error: 'Internal server error during registration' });
  }
});

// --- POST /auth/login ---
app.post('/auth/login', async (req, res) => {
  const parsed = loginSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: 'Invalid input', details: parsed.error.flatten() });
  }
  const { phone, password } = parsed.data;

  try {
    const result = await query(
      'SELECT user_id, role, name, phone, password_hash FROM users WHERE phone = $1',
      [phone]
    );
    if (result.rows.length === 0) {
      // Same error for "not found" and "wrong password" — don't leak which one.
      return res.status(401).json({ error: 'Invalid phone or password' });
    }

    const user = result.rows[0];
    const valid = await verifyPassword(password, user.password_hash);
    if (!valid) {
      return res.status(401).json({ error: 'Invalid phone or password' });
    }

    const accessToken = signAccessToken(user);
    const refreshToken = signRefreshToken(user);
    const decoded = verifyRefreshToken(refreshToken);

    await query(
      `INSERT INTO refresh_tokens (user_id, token_hash, expires_at)
       VALUES ($1, $2, to_timestamp($3))`,
      [user.user_id, hashToken(refreshToken), decoded.exp]
    );

    res.status(200).json({
      user: { id: user.user_id, role: user.role, name: user.name, phone: user.phone },
      accessToken,
      refreshToken,
    });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Internal server error during login' });
  }
});

// --- POST /auth/refresh ---
app.post('/auth/refresh', async (req, res) => {
  const { refreshToken } = req.body;
  if (!refreshToken) {
    return res.status(400).json({ error: 'Missing refreshToken' });
  }

  try {
    const decoded = verifyRefreshToken(refreshToken);
    const tokenHash = hashToken(refreshToken);

    const stored = await query(
      `SELECT token_id, revoked, expires_at FROM refresh_tokens
       WHERE user_id = $1 AND token_hash = $2`,
      [decoded.sub, tokenHash]
    );

    if (stored.rows.length === 0 || stored.rows[0].revoked) {
      return res.status(401).json({ error: 'Refresh token is invalid or has been revoked' });
    }

    const userResult = await query('SELECT user_id, role, name, phone FROM users WHERE user_id = $1', [decoded.sub]);
    if (userResult.rows.length === 0) {
      return res.status(401).json({ error: 'User no longer exists' });
    }

    const accessToken = signAccessToken(userResult.rows[0]);
    res.status(200).json({ accessToken });
  } catch (err) {
    return res.status(401).json({ error: 'Invalid or expired refresh token' });
  }
});

// --- POST /auth/logout ---
app.post('/auth/logout', async (req, res) => {
  const { refreshToken } = req.body;
  if (!refreshToken) {
    return res.status(400).json({ error: 'Missing refreshToken' });
  }
  try {
    const tokenHash = hashToken(refreshToken);
    await query('UPDATE refresh_tokens SET revoked = true WHERE token_hash = $1', [tokenHash]);
    res.status(200).json({ message: 'Logged out' });
  } catch (err) {
    console.error('Logout error:', err);
    res.status(500).json({ error: 'Internal server error during logout' });
  }
});

app.get('/health', (req, res) => res.status(200).send('OK'));

app.listen(PORT, () => {
  console.log(`Auth Service listening on port ${PORT}`);
});
