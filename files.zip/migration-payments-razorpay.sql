-- Run this inside psql: docker exec -it ride-hailing-backend-postgres-1 psql -U admin -d ridehail

ALTER TABLE payments ADD COLUMN IF NOT EXISTS razorpay_order_id VARCHAR(255);
ALTER TABLE payments ADD COLUMN IF NOT EXISTS razorpay_payment_id VARCHAR(255);
ALTER TABLE payments ADD COLUMN IF NOT EXISTS razorpay_signature VARCHAR(500);
ALTER TABLE payments ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP;

-- Prevent duplicate orders if the TRIP_ENDED event is ever redelivered
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'payments_trip_id_unique'
  ) THEN
    ALTER TABLE payments ADD CONSTRAINT payments_trip_id_unique UNIQUE (trip_id);
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_payments_razorpay_order_id ON payments(razorpay_order_id);
