-- Migration 001: Auth, driver profiles, and payment ledger
-- Run this after the existing init.sql. Safe to re-run (uses IF NOT EXISTS / guarded ALTERs).

CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- =========================================================
-- 1. Users (riders and drivers share one identity table)
-- =========================================================
CREATE TABLE IF NOT EXISTS users (
    user_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    role VARCHAR(20) NOT NULL CHECK (role IN ('rider', 'driver')),
    name VARCHAR(255) NOT NULL,
    phone VARCHAR(20) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_users_phone ON users(phone);
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);

-- =========================================================
-- 2. Driver profiles (1:1 extension of users where role = 'driver')
-- =========================================================
CREATE TABLE IF NOT EXISTS driver_profiles (
    user_id UUID PRIMARY KEY REFERENCES users(user_id) ON DELETE CASCADE,
    license_number VARCHAR(100) NOT NULL,
    vehicle_info JSONB,
    is_verified BOOLEAN DEFAULT false,
    is_available BOOLEAN DEFAULT false,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- =========================================================
-- 3. Refresh tokens (for JWT rotation / logout support)
-- =========================================================
CREATE TABLE IF NOT EXISTS refresh_tokens (
    token_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    token_hash VARCHAR(255) NOT NULL,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    revoked BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_refresh_tokens_user_id ON refresh_tokens(user_id);

-- =========================================================
-- 4. Existing drivers table: link to users instead of standing alone
--    (drivers table stays for PostGIS location history; driver_id now
--    must correspond to a real users.user_id with role = 'driver')
-- =========================================================
ALTER TABLE drivers
    ADD CONSTRAINT fk_drivers_user
    FOREIGN KEY (driver_id) REFERENCES users(user_id)
    ON DELETE CASCADE;

-- Drop the placeholder auto-created "name" pattern going forward;
-- name now lives on users. Keeping the column for backward read-compat
-- during rollout, but new writes should stop populating it.
ALTER TABLE drivers ALTER COLUMN name DROP NOT NULL;

-- =========================================================
-- 5. Trips: persist the estimate, track who canceled, add sub-state
-- =========================================================
ALTER TABLE trips ADD COLUMN IF NOT EXISTS rider_id_fk UUID REFERENCES users(user_id);
ALTER TABLE trips ADD COLUMN IF NOT EXISTS estimated_fare DECIMAL(10, 2);
ALTER TABLE trips ADD COLUMN IF NOT EXISTS canceled_by VARCHAR(20) CHECK (canceled_by IN ('rider', 'driver', NULL));
ALTER TABLE trips ADD COLUMN IF NOT EXISTS canceled_at TIMESTAMP WITH TIME ZONE;

-- Note: rider_id (varchar) is kept temporarily for backward compatibility
-- with any in-flight trips; new code should read/write rider_id_fk and
-- rider_id can be dropped in a follow-up migration once verified clean.

-- =========================================================
-- 6. Payments ledger
-- =========================================================
CREATE TABLE IF NOT EXISTS payments (
    payment_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    trip_id UUID NOT NULL REFERENCES trips(trip_id),
    amount DECIMAL(10, 2) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'succeeded', 'failed')),
    provider_ref VARCHAR(255),
    failure_reason TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_payments_trip_id ON payments(trip_id);
CREATE INDEX IF NOT EXISTS idx_payments_status ON payments(status);

-- =========================================================
-- 7. Dead-letter table for events that repeatedly fail processing
--    (referenced in PRD 4.8 — used by history/payment consumers)
-- =========================================================
CREATE TABLE IF NOT EXISTS failed_events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    stream_name VARCHAR(100) NOT NULL,
    event_type VARCHAR(100),
    payload JSONB,
    error_message TEXT,
    attempts INTEGER DEFAULT 1,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
