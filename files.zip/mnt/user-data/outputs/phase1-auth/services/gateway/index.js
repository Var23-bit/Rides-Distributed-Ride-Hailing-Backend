const express = require('express');
const cors = require('cors');
const { createProxyMiddleware } = require('http-proxy-middleware');
const { requireAuth } = require('./middleware/auth');

const app = express();
app.use(cors());
// Still no express.json() here — see the note in the original gateway:
// body-parsing here would consume the stream and break proxied POST/PATCH
// requests. The auth middleware only reads headers, so it doesn't need it.

const AUTH_URL = process.env.AUTH_SERVICE_URL || 'http://auth-service:3004';
const RIDE_URL = process.env.RIDE_SERVICE_URL || 'http://ride-service:3001';
const LOCATION_URL = process.env.LOCATION_SERVICE_URL || 'http://location-service:3002';
const FARE_URL = process.env.FARE_SERVICE_URL || 'http://fare-service:3003';

const makeProxy = (target) =>
  createProxyMiddleware({
    target,
    changeOrigin: true,
    pathRewrite: (path) => path,
    logLevel: 'warn',
  });

// Auth routes are public (register/login/refresh) except where noted
// inside middleware/auth.js's PUBLIC_PATHS list.
app.use('/auth', makeProxy(AUTH_URL));

// Everything below this line requires a verified access token.
app.use(requireAuth);

app.use('/rides', makeProxy(RIDE_URL));
app.use('/health', makeProxy(RIDE_URL));
app.use('/drivers', makeProxy(LOCATION_URL));
app.use('/fares', makeProxy(FARE_URL));

app.get('/', (req, res) => {
  res.json({
    message: 'Ride Hailing API Gateway',
    routes: {
      auth: '/auth',
      rides: '/rides',
      drivers: '/drivers',
      fares: '/fares',
      health: '/health',
    },
  });
});

const PORT = process.env.PORT || 80;
app.listen(PORT, () => {
  console.log(`Gateway listening on port ${PORT}`);
});
