// services/gateway/middleware/auth.js
const { verifyAccessToken } = require('shared/auth');

// Routes that don't require a token (registration/login must be reachable
// without one; health checks stay open for uptime monitors/load balancers).
const PUBLIC_PATHS = [
  { method: 'POST', path: '/auth/register' },
  { method: 'POST', path: '/auth/login' },
  { method: 'POST', path: '/auth/refresh' },
  { method: 'GET', path: '/health' },
];

function isPublic(req) {
  return PUBLIC_PATHS.some((p) => p.method === req.method && req.path.startsWith(p.path));
}

function requireAuth(req, res, next) {
  if (isPublic(req)) return next();

  const header = req.headers['authorization'];
  if (!header || !header.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Missing or malformed Authorization header' });
  }

  const token = header.slice('Bearer '.length);

  try {
    const decoded = verifyAccessToken(token);
    // Attach verified identity for downstream use.
    req.user = { id: decoded.sub, role: decoded.role };

    // CRITICAL: overwrite any client-supplied identity fields with the
    // verified identity before this request is proxied onward. This is
    // what stops a caller from setting `riderId`/`driverId` to someone
    // else's id in the request body.
    req.headers['x-user-id'] = decoded.sub;
    req.headers['x-user-role'] = decoded.role;

    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid or expired access token' });
  }
}

module.exports = { requireAuth };
